package tp.pr2;
import java.util.Scanner;

import tp.pr2.Directions;
import tp.pr2.Room;
import tp.pr2.Parser;
import tp.pr2.Constants;

public class Game {

	private Room currentRoom;
	private Map map;
	private Player player;
	
	
	
	//Default constructor. Creates a new player
	public Game(Map var_map, Room initialRoom){

	this.currentRoom = initialRoom;
	this.map = var_map;
	this.player = new Player();
	}
	
	//Tries to change the room where the player is located, moving him into another room.
	protected void changeRoom(Directions direction){
		
		boolean encontrado = false;
		
		for(int i = 0;i < this.map.getDoors().size(); i++){
			if(this.map.getDoors().get(i).isInRoom(this.currentRoom, direction)){ //If there is a door in that direction in the current room
				encontrado = true;
				
				if(this.map.getDoors().get(i).isInRoom(this.currentRoom)){ //If the door is in the current room
					
					if(this.map.getDoors().get(i).getSource() == this.currentRoom){
						
						if(this.map.getDoors().get(i).isOpen()){
							
							this.currentRoom = this.map.getDoors().get(i).getTarget(); //Changes the current room to the target room
							this.player.addHealth(Constants.LOST_LIVE);
							System.out.println(Constants.MESSAGE_CHANGE_ROOM + direction.name());
							System.out.println(this.currentRoom.getDescription());
							if(!this.currentRoom.isExit())
								System.out.println("HEALTH = " + this.player.getHealth() + ", SCORE =" + this.player.getScore());
							
						}
						else //If the door is closed
							System.out.println("There is a door in the " + direction + ", but it is closed.");
					
					}
					else { //The door is bidirectional and the player is in the target room
						
						if(this.map.getDoors().get(i).isOpen()){
							
							this.currentRoom = this.map.getDoors().get(i).getSource(); //Changes the current room to the source room
							this.player.addHealth(Constants.LOST_LIVE);
							System.out.println(Constants.MESSAGE_CHANGE_ROOM + direction.name());
							System.out.println(this.currentRoom.getDescription());
							if(!this.currentRoom.isExit())
								System.out.println("HEALTH = " + this.player.getHealth() + ", SCORE =" + this.player.getScore());
							
						}
						else //If the door is closed
							System.out.println("There is a door in the " + direction + ", but it is closed.");
						
					}					
				}
				else //The door isn't in the current room
					System.out.println(Constants.MESSAGE_DOOR);
			}
		}
		if(!encontrado) //There is no door in that direction in the current room
			System.out.println(Constants.MESSAGE_WALL + direction.name() + " ?");
	}


	//Initializes the application. Returns false if the start room is null
	public boolean initGame(Room startRoom){
		
		boolean ok = false;
		
		if(startRoom != null){
			ok = true;
			this.currentRoom = startRoom;
		} 
				
		return ok;
	}
	
	//Given a command, process (that is: execute) the command.
	protected boolean processCommand(Command command){
		
		boolean exit = false;
		
		if(command.getVerb() == VerbCommands.QUIT)
			exit = true;
		
		else if(command.getVerb() == VerbCommands.HELP)
			
			System.out.println(Parser.getHelp());
		
		else if(command.getVerb() == VerbCommands.GO){
			
			if(command.getDirection() != Directions.UNKNOWN){
				this.changeRoom(command.getDirection());
					if(this.getCurrentRoom().isExit())
						exit = true;
			}
			
		}
		else if(command.getVerb() == VerbCommands.EXAMINE){
			
			System.out.println(this.currentRoom.getDescription());
			System.out.println("HEALTH = " + this.player.getHealth() + ", SCORE = " + this.player.getScore());
			
		}
		else if(command.getVerb() == VerbCommands.LOOK){
			
			if (command.getIdItem().equals("")){ //Look
				
				if(this.player.getInventory().size() <= 0)
					System.out.println(Constants.MESAGE_POOR);
				
				else{ //The player has at least one item in the inventory
					
					System.out.println(Constants.MESSAGE_ITEMS);
					for(int i = 0;i < this.player.getInventory().size(); i++)
						System.out.println(this.player.getInventory().get(i).toString());
					
				}
			}
			else{ //Look + item
				
				if(this.player.getInventory().size() <= 0)
					System.out.println("There is no " + command.getIdItem().toLowerCase() + " in your inventory.");
					
				else{
					boolean encontrado = false;// Creo encontrado para reconocer si existe o no
					for(int i = 0; i < this.player.getInventory().size(); i++){
						
						if(this.player.getInventory().get(i).getId().equals(command.getIdItem().toLowerCase())){							
						
							System.out.println(this.player.getInventory().get(i).toString());
							encontrado = true;
							
						}
							
					}
					if(!encontrado)
						System.out.println("There is no " + command.getIdItem().toLowerCase() + " in your inventory.");
				}
			}
			
		}
		else if(command.getVerb() == VerbCommands.PICK){
			Item item = null;
			
			for(int i = 0; i < this.currentRoom.getItems().size(); i++){// El command de abajo no me deja ponerlo a lower !!! ??
				if(this.currentRoom.getItems().get(i).getId().equals(command.getIdItem()))
					item = this.currentRoom.getItems().get(i);
			}
			
			if(!this.currentRoom.existsItem(command.getIdItem().toLowerCase()))
				System.out.println(Constants.MESSAGE_PICK_ERROR);
				
			else if(!this.player.addItem(item))
				System.out.println("You have another " + command.getIdItem().toLowerCase() + " in your inventory.");
				
			else// Si existe y lo has a�adido... lo quitas de la habitaci�n.
				this.currentRoom.getItems().remove(item);
			
		}
		else if(command.getVerb() == VerbCommands.USE){
			boolean encontrado = false;

			if(this.player.getInventory().size() > 0){
				
				for(int i = 0; i < this.player.getInventory().size(); i++){
					
					if(this.player.getInventory().get(i).getId().equals(command.getIdItem())){// Si quito aqu� el toLowerCase() me quita como 3 fallos, pero ni idea de si est� bien o porqu� hace eso exactamente....
						encontrado = true;						
						
						if(this.player.getInventory().get(i).use(this.player, this.currentRoom)){
							if(this.player.dead())
								exit = true;
							
						}
						else 
							System.out.println(Constants.MESSAGE_CHANGES_ERROR);
					}					
				}
			}
			
			if (!encontrado){
				System.out.println(Constants.MESSAGE_TRY_USE_ITEM_BUT_NOT_EXISTS + command.getIdItem().toLowerCase() + ".");
			}
			
		}			
		
		return exit;
	}
	
	//Returns a reference to the room where the player is currently located.
	public Room getCurrentRoom(){	
		return this.currentRoom;
	}
	
	//Sets the current room
	public void setCurrentRoom(Room current) {
		this.currentRoom = current;
	}

	//Main loop of the game
	public void runGame(){
		
		boolean exit = false;
		Command command;
		Scanner sc = new Scanner(System.in);		
		
		System.out.println(this.currentRoom.getDescription());  //Writes the initial room description
		System.out.println("HEALTH = " + this.player.getHealth() + ", SCORE =" + this.player.getScore()); //Writes the initial player information
		
		while(!exit){
			
			do{
				System.out.print("> ");
				java.lang.String com = sc.nextLine();
				command = Parser.nextCommand(com);  //Transforms the string com into a command
				
				if(command.isValid())
					
					exit = this.processCommand(command);
					
				else
					System.out.println("What?");
				
			}
			while(!command.isValid()); // If the command is not valid the user must insert a new command
			
		}
		
		System.out.println("GAME OVER " + '\n' + " Thank you for playing, goodbye.");
		System.out.println("HEALTH = " + this.player.getHealth() + ", SCORE =" + this.player.getScore()); //The end.
				
	}	
		
}