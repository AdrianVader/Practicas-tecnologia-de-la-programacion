package tp.pr2;


////Enum that provides all possible verb commands
public enum VerbCommands {
	
	EXAMINE,
	GO,
	HELP,
	LOOK,
	PICK,
	QUIT,
	UNKNOWN,
	USE
}
