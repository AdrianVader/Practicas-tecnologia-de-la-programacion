package tp.pr2;
import tp.pr2.Directions;
import tp.pr2.VerbCommands;



public class Command {

	private VerbCommands verb;
	private Directions dir;
	private String idItem;
	
	
	//Default constructor with an UNKNOWN verb and direction and a "blank" item id
	public Command(){
		
		this.verb = VerbCommands.UNKNOWN;
		this.dir = Directions.UNKNOWN;
		this.idItem = "";
	}
	
	//Creates a command based on a verb
	public Command(VerbCommands verbCommand){
		
		this.verb = verbCommand;
		this.dir = Directions.UNKNOWN;
		this.idItem = "";
	}
	
	//Creates a command based on a verb and direction
	public Command(VerbCommands verbCommand,Directions direction){
		
		this.verb = verbCommand;
		this.dir = direction;
		this.idItem = "";
	}
	
	//Creates a command based on a verb and an item id
	public Command(VerbCommands verbCommand, java.lang.String id){
		
		this.verb = verbCommand;
		this.dir = Directions.UNKNOWN;
		this.idItem = id;
	}
	

	//Checks if the command is valid
	public boolean isValid(){	
		boolean valid = true;
		
		if(this.verb == VerbCommands.UNKNOWN)
			valid = false;
		else if((this.verb == VerbCommands.GO) && (this.dir == Directions.UNKNOWN))
			valid = false;
		else if((this.verb == VerbCommands.PICK) && (this.idItem.equals("")))
			valid = false;
		else if((this.verb == VerbCommands.USE) && (this.idItem.equals("")))
			valid = false;
			
		return valid;
	}
	
	
	//Returns the verb contained in the command
	public VerbCommands getVerb(){
		
		return this.verb;
	}
	
	
	//Returns the direction contained in the command
	public Directions getDirection(){
		
		return this.dir;
	}
	
	//Sets the command verb
	public void setVerb(VerbCommands verbCommand){
		
		this.verb = verbCommand;
	}
	
	
	//Sets the command direction
	public void setDirection(Directions direction){
		
		this.dir = direction;
	}
	
	//Sets the command item
	public String getIdItem() {
		return this.idItem;
	}
	
	//Sets the command item
	public void setIdItem(String var_idItem) {
		this.idItem = var_idItem;
	}
	
}
