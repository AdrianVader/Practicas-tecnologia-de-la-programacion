package tp.pr2;



public class Parser {
	
	
	public Parser(){// Y si lo borramos ?
		
	}
	
	//Returns information about all the commands that the game understands
	public static java.lang.String getHelp(){

		java.lang.String help = "You are lost. You are alone. You wander around" + '\n' + "Your command words are:\n    GO { NORTH|EAST|SOUTH|WEST }\n    HELP\n    QUIT\n    PICK <<id>>\n    USE <<id>>\n    LOOK [<<id>>]\n    EXAMINE";
		return help;
	}
	
	//Parses the next command in the String. It returns a command
	public static Command nextCommand (java.lang.String line){
		
		java.lang.String words[] = line.split(" ");  //Splits the string in words
		Command command = new Command();
		
		if (words.length == 2){
			if (words[0].toUpperCase().equals(VerbCommands.GO.name())){
					
				command.setVerb(VerbCommands.GO);
					
				if(words[1].toUpperCase().equals(Directions.NORTH.name()))
					command.setDirection(Directions.NORTH);
					
				else if(words[1].toUpperCase().equals(Directions.SOUTH.name()))
					command.setDirection(Directions.SOUTH);
				
				else if(words[1].toUpperCase().equals(Directions.EAST.name()))
					command.setDirection(Directions.EAST);
				
				else if(words[1].toUpperCase().equals(Directions.WEST.name()))
					command.setDirection(Directions.WEST);
				
				else
					command.setDirection(Directions.UNKNOWN);  //If the second (and last) word isn't a valid direction
				
				command.setIdItem("");
			}
			
			else if (words[0].toUpperCase().equals(VerbCommands.PICK.name())){
				command.setVerb(VerbCommands.PICK);
				command.setDirection(Directions.UNKNOWN);
				command.setIdItem(words[1]);
			}
			
			else if (words[0].toUpperCase().equals(VerbCommands.USE.name())){
				command.setVerb(VerbCommands.USE);
				command.setDirection(Directions.UNKNOWN);
				command.setIdItem(words[1]);
			}
			
			else if (words[0].toUpperCase().equals(VerbCommands.LOOK.name())){
				command.setVerb(VerbCommands.LOOK);
				command.setDirection(Directions.UNKNOWN);
				command.setIdItem(words[1]);
			}
		}
		
		else if (words.length == 1){
			
			if ((words[0].toUpperCase().equals(VerbCommands.GO.name())))
				command.setVerb(VerbCommands.GO);
			
			else if(words[0].toUpperCase().equals(VerbCommands.HELP.name()))
				command.setVerb(VerbCommands.HELP);
			
			else if(words[0].toUpperCase().equals(VerbCommands.QUIT.name()))
				command.setVerb(VerbCommands.QUIT);
			
			else if(words[0].toUpperCase().equals(VerbCommands.LOOK.name()))
				command.setVerb(VerbCommands.LOOK);
			
			else if(words[0].toUpperCase().equals(VerbCommands.EXAMINE.name()))
				command.setVerb(VerbCommands.EXAMINE);
			
			else if(words[0].toUpperCase().equals(VerbCommands.PICK.name()))
				command.setVerb(VerbCommands.PICK);
			
			else if(words[0].toUpperCase().equals(VerbCommands.USE.name()))
				command.setVerb(VerbCommands.USE);
			
			else
				command.setVerb(VerbCommands.UNKNOWN); //If the word isn't a valid verb command
			
			command.setDirection(Directions.UNKNOWN);  //In this case the direction is always unknown
			command.setIdItem("");
		}
		
		else{
			command.setVerb(VerbCommands.UNKNOWN);
			command.setDirection(Directions.UNKNOWN);
			command.setIdItem("");
		}
		return command;
	}

}
