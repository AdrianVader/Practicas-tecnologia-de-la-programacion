package tp.pr2;

public class Main {

}
